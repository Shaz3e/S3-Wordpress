<?php
/**
 * The template for displaying Pagination
 *
 * @package WordPress
 * @subpackage S3Wordpress
 * @since S3 Framework 1.0
 */
?>
<?php s3_numeric_posts_nav(); ?>
