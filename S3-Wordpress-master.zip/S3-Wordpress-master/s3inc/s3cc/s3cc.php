<?php
	if( s3_option('s3cc_style') == s3_option('s3cc_style')){
		include(TEMPLATEPATH  . "/s3inc/s3cc/s3cc-".s3_option('s3cc_style').".php");
		
	}
?>