<?php

/**
 * Template Name: Layout: Without Post
 * @since S3 Framework 1.0
 */

// Wordpress Header
	get_header();

// Wordpress Footer
	get_footer();
?>