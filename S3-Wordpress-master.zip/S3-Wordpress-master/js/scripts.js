$(document).ready(function(){
    $("#search-open").click(function(){
        $("#s3search").show("fast");
    });
    $("#search-close").click(function(){
        $("#s3search").hide("fast");
    });
});