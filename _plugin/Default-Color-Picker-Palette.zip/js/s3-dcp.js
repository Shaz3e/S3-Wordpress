/**
 * Initialize the default palette
 *
 * @since 1.0.0
 */
( function( $ ) {
	jQuery.wp.wpColorPicker.prototype.options = {
		palettes: dcp.colors
	};
})( jQuery );
