<?php
/*
 * Plugin Name: Default Color Picker Palette
 * Plugin URI: http://shaz3e.com
 * Version: 1.0.0
 * Description: Set the default color picker palette on all instances of the iris color picker.
 * Author: Code Parrots
 * Author URI: http://www.codeparrots.com
 * License: GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

/**
 * Enqueue the script and localize the colors
 *
 * @since 1.0.0
 */
function s3_default_color_picker_palette() {

	$colors = (array) apply_filters( 's3_dcp_palette', [
		'#1cbb5f',
		'#252525',
		'#000000',
		'#FF0000',
		'#800000',
		'#FFFF00',
	] );

	wp_enqueue_script( 's3-dcp', plugin_dir_url( __FILE__ ) . '/js/s3-dcp.js', array( 'wp-color-picker' ), true, '1.0.0' );

	wp_localize_script( 's3-dcp', 'dcp', [
		'colors' => $colors,
	] );

}

add_action( 'admin_enqueue_scripts', 's3_default_color_picker_palette' );
